batted = 1014
not_out = 162
total = 48426
batting = batted - not_out
avg = total / batting
print(avg)