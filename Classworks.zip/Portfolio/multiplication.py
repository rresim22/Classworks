num = int(input("Enter a number:"))
for i in range(1,11):
    result = num*i
    print(num, '*', i, '=', result)