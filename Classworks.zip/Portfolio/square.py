num = [1,2,3,4,5]

sq = []
for i in num:
    sq.append(i**2)
sq