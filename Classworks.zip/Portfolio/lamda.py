x = lambda a,b: a if (a>b) else b

a = int(input("Enter a number"))
b = int(input("Enter a number"))

x = lambda a,b: a if (a>b) else b
print(x)