c=38.4
f= (c*(9/5))+32
print(f)