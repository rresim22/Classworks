group_size = 24
class_size = 113

full_groups = class_size//group_size
left_over= class_size%group_size

print("Fill groups:", full_groups)
print(left_over)