num = int(input("Enter a value:"))
if num % 2 == 0:
    print ("even")
else:
    print("odd")