students = [ ["mark", 50], ["john", 20], ["mike", 25] ]
sorted(students, key= lambda x: x[1], reverse=True)