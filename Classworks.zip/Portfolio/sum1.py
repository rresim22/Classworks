def mysum(x = 0, y = 0, name = "Nobody"):
    print(f"Hello {name}, k cha?")
    return name

mysum(name="Ram")